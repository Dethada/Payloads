<?php

/**
 * Fired during plugin activation
 *
 * @link       Pwn
 * @since      1.0.0
 *
 * @package    Getin
 * @subpackage Getin/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Getin
 * @subpackage Getin/includes
 * @author     Pwn <pwn@pwn.com>
 */
class Getin_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
