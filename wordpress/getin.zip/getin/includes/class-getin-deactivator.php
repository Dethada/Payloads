<?php

/**
 * Fired during plugin deactivation
 *
 * @link       Pwn
 * @since      1.0.0
 *
 * @package    Getin
 * @subpackage Getin/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Getin
 * @subpackage Getin/includes
 * @author     Pwn <pwn@pwn.com>
 */
class Getin_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
